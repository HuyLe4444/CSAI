# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
      A reflex agent chooses an action at each choice point by examining
      its alternatives via a state evaluation function.

      The code below is provided as a guide.  You are welcome to change
      it in any way you see fit, so long as you don't touch our method
      headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {North, South, West, East, Stop}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        # Get Score
        score = successorGameState.getScore()
        
        # Stop waste time so check for it
        if action == 'Stop':
            score -= 10
        
        # GHOST EVALUATION
        # Find minimum distance to any ghost
        ghostPositions = [ghost.getPosition() for ghost in newGhostStates]
        minGhostDistance = min([manhattanDistance(newPos, ghostPos) for ghostPos in ghostPositions]) if ghostPositions else float('inf')
        
        # Handle ghosts differently based on whether they're scared
        areGhostsScared = all(scaredTime > 0 for scaredTime in newScaredTimes)
        
        # If ghosts are scared, we don't need to be as cautious
        if not areGhostsScared:
            # Severely penalize being very close to a ghost
            if minGhostDistance <= 1:
                score -= 500
            # Add penalty inversely proportional to ghost distance when they're close
            elif minGhostDistance <= 3:
                score -= 200 / minGhostDistance
        else:
            # When ghosts are scared, reward being close to them
            if minGhostDistance <= 3:
                score += 100 / (minGhostDistance + 1)
        
        # FOOD EVALUATION
        # Convert food grid to list of positions
        foodList = newFood.asList()
        
        # If there's food, incentivize getting closer to the nearest food
        if foodList:
            # Find distance to closest food
            minFoodDistance = min([manhattanDistance(newPos, food) for food in foodList])
            
            # Add score inversely proportional to distance to closest food
            # The 10.0 multiplier gives this factor more weight
            score += 10.0 / (minFoodDistance + 1)
            
            # Small bonus for states with less remaining food
            score += 100 / (len(foodList) + 1)
        
        # Bonus for eating food in this move
        if currentGameState.getNumFood() > successorGameState.getNumFood():
            score += 100
        
        # Bonus for eating a power capsule
        if len(successorGameState.getCapsules()) < len(currentGameState.getCapsules()):
            score += 150
            
        return score
        return successorGameState.getScore()

def scoreEvaluationFunction(currentGameState):
    """
      This default evaluation function just returns the score of the state.
      The score is the same one displayed in the Pacman GUI.

      This evaluation function is meant for use with adversarial search agents
      (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
      This class provides some common elements to all of your
      multi-agent searchers.  Any methods defined here will be available
      to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

      You *do not* need to make any changes here, but you can if you want to
      add functionality to all your adversarial search agents.  Please do not
      remove anything, however.

      Note: this is an abstract class: one that should not be instantiated.  It's
      only partially specified, and designed to be extended.  Agent (game.py)
      is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
      Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action from the current gameState using self.depth
          and self.evaluationFunction.

          Here are some method calls that might be useful when implementing minimax.

          gameState.getLegalActions(agentIndex):
            Returns a list of legal actions for an agent
            agentIndex=0 means Pacman, ghosts are >= 1

          gameState.generateSuccessor(agentIndex, action):
            Returns the successor game state after an agent takes an action

          gameState.getNumAgents():
            Returns the total number of agents in the game
        """
        "*** YOUR CODE HERE ***"
        # Initialize the best action and value
        bestAction = None
        bestValue = float("-inf")
        
        # Get legal actions for Pacman (agent index 0)
        legalActions = gameState.getLegalActions(0)
        
        # For each possible action from the current state
        for action in legalActions:
            # Get the successor state after taking this action
            successorState = gameState.generateSuccessor(0, action)
            
            # Calculate the minimax value for this successor state
            # Start with agent 1 (first ghost), at depth 0
            value = self.minimax(successorState, 0, 1)
            
            # Update the best action if this value is better
            if value > bestValue:
                bestValue = value
                bestAction = action
        
        return bestAction
    
    def minimax(self, gameState, currentDepth, agentIndex):
        """
        Recursive minimax function
        
        Args:
            gameState: The current game state
            currentDepth: Current depth in the game tree
            agentIndex: Index of the current agent (0 for Pacman, 1+ for ghosts)
            
        Returns:
            The minimax value for the current state
        """
        # Get the total number of agents (Pacman + ghosts)
        numAgents = gameState.getNumAgents()
        
        # Check if we've reached a terminal state
        if gameState.isWin() or gameState.isLose() or currentDepth == self.depth:
            return self.evaluationFunction(gameState)
        
        # If we're at Pacman's turn (max player)
        if agentIndex == 0:
            return self.maxValue(gameState, currentDepth)
        # If we're at a ghost's turn (min player)
        else:
            return self.minValue(gameState, currentDepth, agentIndex)
    
    def maxValue(self, gameState, currentDepth):
        """
        Calculate the maximum value for Pacman (agent 0)
        """
        # Initialize value to negative infinity
        value = float("-inf")
        
        # Get legal actions for Pacman
        legalActions = gameState.getLegalActions(0)
        
        # If there are no legal actions, return the evaluation
        if not legalActions:
            return self.evaluationFunction(gameState)
        
        # For each possible action
        for action in legalActions:
            # Generate successor state
            successorState = gameState.generateSuccessor(0, action)
            
            # Calculate the value for this successor state
            # Next agent is the first ghost (agent 1)
            successorValue = self.minimax(successorState, currentDepth, 1)
            
            # Update the maximum value
            value = max(value, successorValue)
        
        return value
    
    def minValue(self, gameState, currentDepth, agentIndex):
        """
        Calculate the minimum value for a ghost
        """
        # Initialize value to positive infinity
        value = float("inf")
        
        # Get legal actions for this ghost
        legalActions = gameState.getLegalActions(agentIndex)
        
        # If there are no legal actions, return the evaluation
        if not legalActions:
            return self.evaluationFunction(gameState)
        
        # Get the total number of agents
        numAgents = gameState.getNumAgents()
        
        # For each possible action
        for action in legalActions:
            # Generate successor state
            successorState = gameState.generateSuccessor(agentIndex, action)
            
            # Calculate the value for this successor state
            # Determine the next agent
            nextAgent = agentIndex + 1
            
            # If we've considered all agents, go to the next depth
            # and back to Pacman (agent 0)
            if nextAgent == numAgents:
                nextAgent = 0
                successorValue = self.minimax(successorState, currentDepth + 1, nextAgent)
            else:
                # Otherwise, continue with the next ghost
                successorValue = self.minimax(successorState, currentDepth, nextAgent)
            
            # Update the minimum value
            value = min(value, successorValue)
        
        return value

class AlphaBetaAgent(MultiAgentSearchAgent):
    """
      Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
          Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"
        # Initialize alpha and beta values
        alpha = float("-inf")
        beta = float("inf")
        
        # Initialize the best action and value
        bestAction = None
        bestValue = float("-inf")
        
        # Get legal actions for Pacman (agent index 0)
        legalActions = gameState.getLegalActions(0)
        
        # For each possible action from the current state
        for action in legalActions:
            # Get the successor state after taking this action
            successorState = gameState.generateSuccessor(0, action)
            
            # Calculate the minimax value with alpha-beta pruning for this successor state
            # Start with agent 1 (first ghost), at depth 0
            value = self.alphaBeta(successorState, 0, 1, alpha, beta)
            
            # Update the best action if this value is better
            if value > bestValue:
                bestValue = value
                bestAction = action
            
            # Update alpha value
            alpha = max(alpha, bestValue)
        
        return bestAction
    
    def alphaBeta(self, gameState, currentDepth, agentIndex, alpha, beta):
        """
        Recursive alpha-beta pruning function
        
        Args:
            gameState: The current game state
            currentDepth: Current depth in the game tree
            agentIndex: Index of the current agent (0 for Pacman, 1+ for ghosts)
            alpha: The alpha value (best value for MAX found so far)
            beta: The beta value (best value for MIN found so far)
            
        Returns:
            The minimax value for the current state with alpha-beta pruning
        """
        # Get the total number of agents (Pacman + ghosts)
        numAgents = gameState.getNumAgents()
        
        # Check if we've reached a terminal state
        if gameState.isWin() or gameState.isLose() or currentDepth == self.depth:
            return self.evaluationFunction(gameState)
        
        # If we're at Pacman's turn (max player)
        if agentIndex == 0:
            return self.maxValue(gameState, currentDepth, alpha, beta)
        # If we're at a ghost's turn (min player)
        else:
            return self.minValue(gameState, currentDepth, agentIndex, alpha, beta)
    
    def maxValue(self, gameState, currentDepth, alpha, beta):
        """
        Calculate the maximum value for Pacman (agent 0) with alpha-beta pruning
        """
        # Initialize value to negative infinity
        value = float("-inf")
        
        # Get legal actions for Pacman
        legalActions = gameState.getLegalActions(0)
        
        # If there are no legal actions, return the evaluation
        if not legalActions:
            return self.evaluationFunction(gameState)
        
        # For each possible action
        for action in legalActions:
            # Generate successor state
            successorState = gameState.generateSuccessor(0, action)
            
            # Calculate the value for this successor state
            # Next agent is the first ghost (agent 1)
            successorValue = self.alphaBeta(successorState, currentDepth, 1, alpha, beta)
            
            # Update the maximum value
            value = max(value, successorValue)
            
            # Prune if possible
            if value > beta:
                return value
            
            # Update alpha value
            alpha = max(alpha, value)
        
        return value
    
    def minValue(self, gameState, currentDepth, agentIndex, alpha, beta):
        """
        Calculate the minimum value for a ghost with alpha-beta pruning
        """
        # Initialize value to positive infinity
        value = float("inf")
        
        # Get legal actions for this ghost
        legalActions = gameState.getLegalActions(agentIndex)
        
        # If there are no legal actions, return the evaluation
        if not legalActions:
            return self.evaluationFunction(gameState)
        
        # Get the total number of agents
        numAgents = gameState.getNumAgents()
        
        # For each possible action
        for action in legalActions:
            # Generate successor state
            successorState = gameState.generateSuccessor(agentIndex, action)
            
            # Calculate the value for this successor state
            # Determine the next agent
            nextAgent = agentIndex + 1
            
            # If we've considered all agents, go to the next depth
            # and back to Pacman (agent 0)
            if nextAgent == numAgents:
                nextAgent = 0
                successorValue = self.alphaBeta(successorState, currentDepth + 1, nextAgent, alpha, beta)
            else:
                # Otherwise, continue with the next ghost
                successorValue = self.alphaBeta(successorState, currentDepth, nextAgent, alpha, beta)
            
            # Update the minimum value
            value = min(value, successorValue)
            
            # Prune if possible
            if value < alpha:
                return value
            
            # Update beta value
            beta = min(beta, value)
        
        return value
        util.raiseNotDefined()

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
          Returns the expectimax action using self.depth and self.evaluationFunction

          All ghosts should be modeled as choosing uniformly at random from their
          legal moves.
        """
        "*** YOUR CODE HERE ***"
        # Initialize the best action and value
        bestAction = None
        bestValue = float("-inf")
        
        # Get legal actions for Pacman (agent index 0)
        legalActions = gameState.getLegalActions(0)
        
        # For each possible action from the current state
        for action in legalActions:
            # Get the successor state after taking this action
            successorState = gameState.generateSuccessor(0, action)
            
            # Calculate the expectimax value for this successor state
            # Start with agent 1 (first ghost), at depth 0
            value = self.expectimax(successorState, 0, 1)
            
            # Update the best action if this value is better
            if value > bestValue:
                bestValue = value
                bestAction = action
        
        return bestAction
    
    def expectimax(self, gameState, currentDepth, agentIndex):
        """
        Recursive expectimax function
        
        Args:
            gameState: The current game state
            currentDepth: Current depth in the game tree
            agentIndex: Index of the current agent (0 for Pacman, 1+ for ghosts)
            
        Returns:
            The expectimax value for the current state
        """
        # Get the total number of agents (Pacman + ghosts)
        numAgents = gameState.getNumAgents()
        
        # Check if we've reached a terminal state
        if gameState.isWin() or gameState.isLose() or currentDepth == self.depth:
            return self.evaluationFunction(gameState)
        
        # If we're at Pacman's turn (max player)
        if agentIndex == 0:
            return self.maxValue(gameState, currentDepth)
        # If we're at a ghost's turn (chance player)
        else:
            return self.expValue(gameState, currentDepth, agentIndex)
    
    def maxValue(self, gameState, currentDepth):
        """
        Calculate the maximum value for Pacman (agent 0)
        """
        # Initialize value to negative infinity
        value = float("-inf")
        
        # Get legal actions for Pacman
        legalActions = gameState.getLegalActions(0)
        
        # If there are no legal actions, return the evaluation
        if not legalActions:
            return self.evaluationFunction(gameState)
        
        # For each possible action
        for action in legalActions:
            # Generate successor state
            successorState = gameState.generateSuccessor(0, action)
            
            # Calculate the value for this successor state
            # Next agent is the first ghost (agent 1)
            successorValue = self.expectimax(successorState, currentDepth, 1)
            
            # Update the maximum value
            value = max(value, successorValue)
        
        return value
    
    def expValue(self, gameState, currentDepth, agentIndex):
        """
        Calculate the expected value for a ghost (chance player)
        assuming uniform random choice of actions
        """
        # Initialize value to 0 for expectation calculation
        value = 0.0
        
        # Get legal actions for this ghost
        legalActions = gameState.getLegalActions(agentIndex)
        
        # If there are no legal actions, return the evaluation
        if not legalActions:
            return self.evaluationFunction(gameState)
        
        # Calculate probability for each action (uniform distribution)
        probability = 1.0 / len(legalActions)
        
        # Get the total number of agents
        numAgents = gameState.getNumAgents()
        
        # For each possible action
        for action in legalActions:
            # Generate successor state
            successorState = gameState.generateSuccessor(agentIndex, action)
            
            # Calculate the value for this successor state
            # Determine the next agent
            nextAgent = agentIndex + 1
            
            # If we've considered all agents, go to the next depth
            # and back to Pacman (agent 0)
            if nextAgent == numAgents:
                nextAgent = 0
                successorValue = self.expectimax(successorState, currentDepth + 1, nextAgent)
            else:
                # Otherwise, continue with the next ghost
                successorValue = self.expectimax(successorState, currentDepth, nextAgent)
            
            # Add the weighted value to our expectation
            value += probability * successorValue
        
        return value
        util.raiseNotDefined()

def betterEvaluationFunction(currentGameState):
    """
      Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
      evaluation function (question 5).

      DESCRIPTION: This evaluation function uses a linear combination of several important features:
      1. Current score - The game score reflects progress so far
      2. Food proximity - Rewards being close to food (using reciprocal of distance)
      3. Food count - Penalizes having more food left (encourages eating)
      4. Ghost proximity - Penalizes being close to non-scared ghosts, rewards being close to scared ghosts
      5. Capsule count - Slightly penalizes having more capsules left
      6. Dead end avoidance - Penalizes positions with few escape routes
      
      Each feature is weighted according to its importance, with careful balancing to ensure
      Pacman prioritizes food collection while maintaining a safe distance from dangerous ghosts.
    """
    "*** YOUR CODE HERE ***"
    # If this is a win or lose state, return accordingly
    if currentGameState.isWin():
        return float("inf")
    if currentGameState.isLose():
        return float("-inf")
    
    # Get useful information from the state
    pos = currentGameState.getPacmanPosition()  # Pacman position
    food = currentGameState.getFood()  # Food grid
    foodList = food.asList()  # Food positions as list
    ghostStates = currentGameState.getGhostStates()  # Ghost states
    scaredTimes = [ghostState.scaredTimer for ghostState in ghostStates]  # Ghost scared timers
    capsules = currentGameState.getCapsules()  # Power capsules
    
    # Start with the current score as the base value
    score = currentGameState.getScore()
    
    # --- FOOD EVALUATION ---
    # Distance to closest food
    if foodList:
        foodDistances = [manhattanDistance(pos, foodPos) for foodPos in foodList]
        minFoodDist = min(foodDistances)
        # Reward being close to food (using reciprocal)
        score += 10.0 / (minFoodDist + 1)
        
        # Penalty for remaining food (encourages eating)
        score -= 4 * len(foodList)
        
        # Calculate food dispersion (reward clustering of remaining food)
        avgFoodDist = sum(foodDistances) / len(foodDistances)
        score -= avgFoodDist * 0.5  # Smaller penalty for widely dispersed food
    
    # --- GHOST EVALUATION ---
    for i, ghostState in enumerate(ghostStates):
        ghostPos = ghostState.getPosition()
        ghostDist = manhattanDistance(pos, ghostPos)
        
        # If the ghost is scared, we want to chase it
        if scaredTimes[i] > ghostDist:
            # Reward being close to scared ghosts
            score += 200.0 / (ghostDist + 1)
        else:
            # Penalize being close to active ghosts
            if ghostDist <= 1:
                # Severely penalize being adjacent to a ghost
                score -= 500
            elif ghostDist <= 3:
                # Moderate penalty for being somewhat close
                score -= 200.0 / (ghostDist + 1)
            else:
                # Small penalty for being in the same area
                score -= 10.0 / (ghostDist + 1)
    
    # --- POWER CAPSULE EVALUATION ---
    # Small bonus for having capsules nearby (inversely proportional to distance)
    if capsules:
        closestCapsuleDist = min([manhattanDistance(pos, capsule) for capsule in capsules])
        score += 20.0 / (closestCapsuleDist + 1)
        
        # Small penalty for remaining capsules (encourages eating them)
        score -= 10 * len(capsules)
    
    # --- POSITION EVALUATION ---
    # Count legal actions as a measure of mobility/escape routes
    # This helps avoid dead-ends
    legalActions = currentGameState.getLegalPacmanActions()
    # Penalize positions with few escape routes (avoiding 'Stop')
    numEscapeRoutes = len(legalActions) - ('Stop' in legalActions)
    score += 10 * numEscapeRoutes
    
    # --- STRATEGIC PLANNING ---
    # If there are scared ghosts and we have time to catch them, prioritize that
    if any(scared > 0 for scared in scaredTimes):
        maxScaredTime = max(scaredTimes)
        # If ghosts are scared, temporarily reduce the importance of food
        if maxScaredTime > 5:
            # Focus more on ghosts and less on food when ghosts are scared
            score += 100
    
    return score
    util.raiseNotDefined()

# Abbreviation
better = betterEvaluationFunction

