# valueIterationAgents.py
# -----------------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


import mdp, util

from learningAgents import ValueEstimationAgent

class ValueIterationAgent(ValueEstimationAgent):
    """
        * Please read learningAgents.py before reading this.*

        A ValueIterationAgent takes a Markov decision process
        (see mdp.py) on initialization and runs value iteration
        for a given number of iterations using the supplied
        discount factor.
    """
    def __init__(self, mdp, discount = 0.9, iterations = 100):
        """
          Your value iteration agent should take an mdp on
          construction, run the indicated number of iterations
          and then act according to the resulting policy.

          Some useful mdp methods you will use:
              mdp.getStates()
              mdp.getPossibleActions(state)
              mdp.getTransitionStatesAndProbs(state, action)
              mdp.getReward(state, action, nextState)
              mdp.isTerminal(state)
        """
        self.mdp = mdp
        self.discount = discount
        self.iterations = iterations
        self.values = util.Counter() # A Counter is a dict with default 0

        # Write value iteration code here
        "*** YOUR CODE HERE ***"
        # Perform value iteration for the specified number of iterations.
        for i in range(self.iterations):
            # Create a new Counter to store the values for the current iteration.
            newValues = util.Counter()
            # Iterate through all states in the MDP.
            for state in self.mdp.getStates():
                # If the state is terminal, its value is 0.
                if self.mdp.isTerminal(state):
                    newValues[state] = 0
                    continue
                # Get the possible actions from the current state.
                actions = self.mdp.getPossibleActions(state)
                # If there are no actions available from this state, its value remains 0.
                if not actions:
                    newValues[state] = 0
                    continue
                # Calculate the Q-value for each possible action from the current state
                # based on the values from the previous iteration.
                qValues = []
                for action in actions:
                    qValues.append(self.computeQValueFromValues(state, action))
                # The value of the current state is the maximum Q-value over all possible actions.
                newValues[state] = max(qValues)
            # Update the values for the next iteration (batch update).
            self.values = newValues


    def getValue(self, state):
        """
          Return the value of the state (computed in __init__).
        """
        return self.values[state]


    def computeQValueFromValues(self, state, action):
        """
          Compute the Q-value of action in state from the
          value function stored in self.values.
        """
        "*** YOUR CODE HERE ***"
        qValue = 0
        # Get the possible transitions from the current state and action.
        transitions = self.mdp.getTransitionStatesAndProbs(state, action)
        # Iterate through each possible next state and its probability.
        for nextState, prob in transitions:
            # Get the reward for the transition to the next state.
            reward = self.mdp.getReward(state, action, nextState)
            # Update the Q-value using the Bellman equation.
            qValue += prob * (reward + self.discount * self.getValue(nextState))
        return qValue
        util.raiseNotDefined()

    def computeActionFromValues(self, state):
        """
          The policy is the best action in the given state
          according to the values currently stored in self.values.

          You may break ties any way you see fit.  Note that if
          there are no legal actions, which is the case at the
          terminal state, you should return None.
        """
        "*** YOUR CODE HERE ***"
        # If the state is terminal, there is no action to take.
        if self.mdp.isTerminal(state):
            return None
        # Get the possible actions from the current state.
        actions = self.mdp.getPossibleActions(state)
        # If there are no actions, return None.
        if not actions:
            return None

        bestAction = None
        bestQValue = float('-inf')

        # Iterate through all possible actions and calculate their Q-values.
        for action in actions:
            qValue = self.computeQValueFromValues(state, action)
            # If the current Q-value is better than the best Q-value found so far,
            # update the best action and best Q-value.
            if qValue > bestQValue:
                bestQValue = qValue
                bestAction = action
        return bestAction
        util.raiseNotDefined()

    def getPolicy(self, state):
        return self.computeActionFromValues(state)

    def getAction(self, state):
        "Returns the policy at the state (no exploration)."
        return self.computeActionFromValues(state)

    def getQValue(self, state, action):
        return self.computeQValueFromValues(state, action)
